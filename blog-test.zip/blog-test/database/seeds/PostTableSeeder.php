<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PostTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i=0; $i<100; $i++) {
            DB::table('post')->insert([
                'slug' => $faker->slug(3),
                'title' => $faker->sentence(4),
            ]);
        }
    }
}
