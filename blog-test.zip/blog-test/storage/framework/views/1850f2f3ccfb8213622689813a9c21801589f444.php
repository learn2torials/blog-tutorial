<h1><?php echo e($post->title); ?></h1>
<hr />
<br />


<small><?php echo e($post->slug); ?></small>
<?php /**PATH /Users/sandip.patel/Projects/blog-test/resources/views/post.blade.php ENDPATH**/ ?>