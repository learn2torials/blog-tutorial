<h1>Recently created posts</h1>
<hr />
<br />

<ul>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route("post_page", ["slug" => $post->slug])); ?>"><?php echo e($post->title); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH /Users/sandip.patel/Projects/blog-test/resources/views/index.blade.php ENDPATH**/ ?>