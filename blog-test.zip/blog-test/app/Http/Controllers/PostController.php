<?php

namespace App\Http\Controllers;

use App\Post;

class PostController extends Controller
{
    function index()
    {
        return view("index", [
            "posts" => Post::all()     // gets all the post from the database
        ]);
    }

    function show($slug)
    {
        return view("post", [
            "post" => Post::where("slug", $slug)->first()    // fetch single post with slug
        ]);
    }
}
