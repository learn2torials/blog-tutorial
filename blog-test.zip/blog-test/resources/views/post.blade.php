<h1>{{ $post->title }}</h1>
<hr />
<br />


<small>{{ $post->slug }}</small>
