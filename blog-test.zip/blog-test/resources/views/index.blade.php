<h1>Recently created posts</h1>
<hr />
<br />

<ul>
    @foreach ($posts as $post)
        <li>
            <a href="{{ route("post_page", ["slug" => $post->slug]) }}">{{ $post->title }}</a>
        </li>
    @endforeach
</ul>
